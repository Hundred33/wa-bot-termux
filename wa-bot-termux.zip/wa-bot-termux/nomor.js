module.exports = {
  nomor: '+62XXXXXXXXXXX' // Ganti dengan nomor kamu (kode negara + nomor)
};
